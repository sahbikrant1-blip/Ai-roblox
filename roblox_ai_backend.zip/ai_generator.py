import os

def generate_model(prompt, model_type, image_path):
    # Create dummy OBJ file for testing
    os.makedirs("generated", exist_ok=True)
    filename = f"generated/{prompt}_{model_type}.obj"
    obj_content = """o Cube
v 0 0 0
v 0 1 0
v 1 1 0
v 1 0 0
f 1 2 3 4
"""
    with open(filename, "w") as f:
        f.write(obj_content)
    return filename
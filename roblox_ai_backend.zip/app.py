from flask import Flask, request, jsonify
import os
from ai_generator import generate_model

app = Flask(__name__)

# Ensure folders exist
os.makedirs("uploads", exist_ok=True)
os.makedirs("generated", exist_ok=True)

@app.route('/generate', methods=['POST'])
def generate():
    prompt = request.form.get('prompt')
    model_type = request.form.get('type')
    image = request.files.get('image')

    if not prompt or not image:
        return jsonify({"error":"Missing prompt or image"}), 400

    # Save uploaded image
    image_path = os.path.join("uploads", image.filename)
    image.save(image_path)

    # Generate 3D model (dummy OBJ for testing)
    output_file = generate_model(prompt, model_type, image_path)

    # Return file URL and preview URL (Replit serves files via /generated)
    return jsonify({
        "file": f"/{output_file}",
        "preview": f"/{output_file}"
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
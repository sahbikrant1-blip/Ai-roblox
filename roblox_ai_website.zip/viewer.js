let scene = new THREE.Scene();
let camera = new THREE.PerspectiveCamera(75, 600/400, 0.1, 1000);
let renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(600, 400);
document.getElementById('viewer').appendChild(renderer.domElement);
camera.position.z = 10;

// Lighting
const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
scene.add(ambientLight);
const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
directionalLight.position.set(10,10,10);
scene.add(directionalLight);

// Orbit controls (optional for rotating/zoom)
const controls = new THREE.OrbitControls(camera, renderer.domElement);

function loadModel(url){
  // Clear previous model but keep lights (first 2 objects)
  while(scene.children.length > 2){
    scene.remove(scene.children[2]);
  }

  // Load OBJ model
  const loader = new THREE.OBJLoader();
  loader.load(url, function(obj){
    scene.add(obj);
    animate();
  }, undefined, function(error){
    console.error('Error loading model:', error);
  });
}

function animate(){
  requestAnimationFrame(animate);
  controls.update();
  renderer.render(scene, camera);
}